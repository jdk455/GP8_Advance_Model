#include "Arduino.h"
#include <AFMotor.h>

void quickspeed_set();
void slowspeed_set();
void go_straight();
void go_back();
void turn_right();
void turn_left();
void Turn_Left();
void Turn_Right();
void stop();
void control(char sr);